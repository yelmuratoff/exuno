---
name: demo
description: Demo skill.
---

Repeat repeat repeat repeat repeat repeat repeat.
